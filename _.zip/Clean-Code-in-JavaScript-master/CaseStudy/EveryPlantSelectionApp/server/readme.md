# AutoSuggestion Server

## Install

```bash
$ npm install
```

## Run

```bash
$ npm start
```

## Data

For the purposes of this demo, the data lives within `./plantData/data.json`.
