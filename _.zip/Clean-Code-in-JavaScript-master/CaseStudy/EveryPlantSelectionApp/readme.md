# AutoSuggestion client & server

This repository includes both the *EveryPlant* *AutoSuggestion* client (React) and server (Node.js).
