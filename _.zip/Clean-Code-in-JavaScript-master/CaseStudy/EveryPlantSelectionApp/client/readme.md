# AutoSuggestion Client

## Install

```bash
$ npm install
```

## Run

```bash
$ npm start
```
